package studi_kasus_1;

public class Firm {
    public static void main(String args[]){
        Staff personnel = new Staff();
        
        personnel.payday();
    }
}
